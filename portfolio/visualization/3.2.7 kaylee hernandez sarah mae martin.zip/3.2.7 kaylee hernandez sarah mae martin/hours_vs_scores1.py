import os.path
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter, FormatStrFormatter
import numpy as np


# Get the directory name for data files
directory = os.path.dirname(os.path.abspath(__file__))

#empty lists for the excel data
hours=[]
scores=[]
countries = []
countries2 = []

# Build an absolute filename from directory + filename
filename = os.path.join(directory, 'hours.csv')
datafile = open(filename,'r')
data = datafile.readlines()

for line in data[1:]: # Omit 0(first row) because we don't need the headers
    country, b, c, d, e, f, hour = line.split(',') #separates each column
    countries.append(str(country)) #change country to a string so we can add it to our countries list

for line in data[1:]: # Omit 0(first row) because we don't need it
    country, b, c, d, e, f, hour = line.split(',')
    hours += [hour] #adds hours to our hours list
    
#close the hours excel file so wecan open an other excel file
datafile.close()

# Build an absolute filename from directory + filename
filename = os.path.join(directory, 'testscores.csv')
datafile = open(filename,'r')
data = datafile.readlines()

for line in data[1:]: # Omit 0 because we don't need the first row
    country, b, c, d, e, f, score = line.split(',')
    countries2.append(str(country))
    
for line in data[1:]: # Omit 0 because we don't need the first row
    country, b, c, d, e, f, score = line.split(',')
    scores += [score] #add scores to our scores list

    
datafile.close()

#Hours Bar Chart
fig, ax = plt.subplots(1,1)
fig.patch.set_facecolor('white') #changes background color to white
y_pos = np.arange(len(countries)) #gives an array of evenly spaced values 
 
ax.bar(y_pos, hours, align='center') #creates bar chart

ax.set_xlabel('Countries') #labels x-axis
ax.set_ylabel('Hours per Week') #labels y-axis
ax.set_title('Teaching Hours by Countries') #sets title
plt.xticks(y_pos, countries) #labels each country on x-axis
plt.xlim(-1+0.5, 32-0.5) #range of x-axis
fig.show() #displays bar chart

#Scores Bar Chart
fig, ax = plt.subplots(1,1)
fig.patch.set_facecolor('white')
y_pos = np.arange(len(countries2))
 
ax.bar(y_pos, scores, align='center')

ax.set_xlabel('Countries')
ax.set_ylabel('PISA Reading Scores')
ax.set_title('PISA Reading Scores by Country')
plt.xticks(y_pos, countries2)
plt.xlim(-1+0.5, 27-0.5)
fig.show()